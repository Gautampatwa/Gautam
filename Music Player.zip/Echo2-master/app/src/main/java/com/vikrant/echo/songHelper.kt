package com.vikrant.echo

class songHelper {
    var songtitle: String? = null
    var songArtist: String? = null
    var songPath: String? = null
    var songID: Long = 0
    var currentPosition: Int? = null
    var isPlay: Boolean = false
    var isRepeat: Boolean = false
    var isShuffle: Boolean = false
    var trackPosition: Int = 0
}